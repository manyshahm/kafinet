import 'package:flutter/material.dart';

class ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const ErrorView({super.key, required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.cloud_off_rounded, size: 52),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('تلاش دوباره')),
          ]),
        ),
      );
}

String money(int amount) {
  final raw = amount.toString();
  final out = StringBuffer();
  for (var i = 0; i < raw.length; i++) {
    final left = raw.length - i;
    out.write(raw[i]);
    if (left > 1 && left % 3 == 1) out.write('٬');
  }
  return '${out.toString()} تومان';
}

String statusLabel(String status) {
  switch (status) {
    case 'reviewing': return 'در حال بررسی';
    case 'need_info': return 'نیاز به اطلاعات';
    case 'processing': return 'در حال انجام';
    case 'done': return 'تکمیل شده';
    case 'cancelled': return 'لغو شده';
    default: return 'ثبت شده';
  }
}
