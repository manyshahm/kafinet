import 'package:flutter/material.dart';
import '../core/app_config.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => SafeArea(child: Scaffold(
        appBar: AppBar(title: const Text('پروفایل')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Card(child: ListTile(leading: CircleAvatar(child: Icon(Icons.water_drop)), title: Text('کافی‌نت چشمه'), subtitle: Text('نسخه آزمایشی Server-Driven'))),
          const SizedBox(height: 12),
          const Card(child: Column(children: [
            ListTile(leading: Icon(Icons.support_agent), title: Text('پشتیبانی'), subtitle: Text('شماره تماس از پنل مدیریت قابل تنظیم است')),
            Divider(height: 1),
            ListTile(leading: Icon(Icons.info_outline), title: Text('درباره برنامه'), subtitle: Text('محتوا و خدمات این برنامه از سرور دریافت می‌شود.')),
          ])),
          const SizedBox(height: 18),
          Text('نسخه ${AppConfig.appVersion}', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
        ]),
      ));
}
