import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/storage.dart';
import '../models/models.dart';
import '../widgets/common.dart';
import 'service_detail_screen.dart';

class ServicesScreen extends StatefulWidget {
  final ApiClient api;
  final LocalStorage storage;
  final CategoryModel category;
  const ServicesScreen({super.key, required this.api, required this.storage, required this.category});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  late Future<List<ServiceModel>> future = widget.api.servicesByCategory(widget.category.id);
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.category.name)),
        body: FutureBuilder<List<ServiceModel>>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) return ErrorView(message: snapshot.error.toString(), onRetry: () => setState(() => future = widget.api.servicesByCategory(widget.category.id)));
            final items = snapshot.data ?? const [];
            if (items.isEmpty) return const Center(child: Text('فعلاً خدمتی در این دسته ثبت نشده است.'));
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final service = items[i];
                return Card(child: ListTile(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ServiceDetailScreen(api: widget.api, storage: widget.storage, serviceId: service.id))),
                  leading: const CircleAvatar(child: Icon(Icons.assignment_outlined)),
                  title: Text(service.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(service.shortDescription),
                  trailing: const Icon(Icons.chevron_left),
                ));
              },
            );
          },
        ),
      );
}
