import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/storage.dart';
import '../models/models.dart';
import '../widgets/common.dart';

class OrdersScreen extends StatefulWidget {
  final ApiClient api;
  final LocalStorage storage;
  const OrdersScreen({super.key, required this.api, required this.storage});
  @override State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> with AutomaticKeepAliveClientMixin {
  Future<List<OrderModel>>? future;
  @override bool get wantKeepAlive => true;

  Future<List<OrderModel>> load() async {
    final key = await widget.storage.getClientKey();
    return widget.api.orders(key);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    future ??= load();
    return SafeArea(child: Scaffold(
      appBar: AppBar(title: const Text('سفارش‌های من'), actions: [IconButton(onPressed: () => setState(() => future = load()), icon: const Icon(Icons.refresh))]),
      body: FutureBuilder<List<OrderModel>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return ErrorView(message: snapshot.error.toString(), onRetry: () => setState(() => future = load()));
          final items = snapshot.data ?? const [];
          if (items.isEmpty) return const Center(child: Text('هنوز سفارشی ثبت نکرده‌اید.'));
          return RefreshIndicator(
            onRefresh: () async => setState(() => future = load()),
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final o = items[i];
                return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [Expanded(child: Text(o.serviceTitle, style: const TextStyle(fontWeight: FontWeight.bold))), Chip(label: Text(statusLabel(o.status)))]),
                  const SizedBox(height: 6),
                  Text('کد پیگیری: ${o.trackingCode}'),
                  if (o.totalAmount > 0) Text('مبلغ: ${money(o.totalAmount)}'),
                  if (o.adminNote.isNotEmpty) ...[const Divider(), Text('پیام کافی‌نت: ${o.adminNote}')],
                ])));
              },
            ),
          );
        },
      ),
    ));
  }
}
