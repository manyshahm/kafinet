import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/storage.dart';
import 'home_screen.dart';
import 'orders_screen.dart';
import 'profile_screen.dart';

class RootScreen extends StatefulWidget {
  final ApiClient api;
  final LocalStorage storage;
  const RootScreen({super.key, required this.api, required this.storage});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  int index = 0;
  late final List<Widget> pages;

  @override
  void initState() {
    super.initState();
    pages = [
      HomeScreen(api: widget.api, storage: widget.storage),
      OrdersScreen(api: widget.api, storage: widget.storage),
      const ProfileScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'سفارش‌ها'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
          ],
        ),
      );
}
