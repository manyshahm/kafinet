import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/storage.dart';
import '../models/models.dart';
import '../widgets/common.dart';
import 'services_screen.dart';
import 'service_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  final ApiClient api;
  final LocalStorage storage;
  const HomeScreen({super.key, required this.api, required this.storage});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with AutomaticKeepAliveClientMixin {
  late Future<BootstrapData> future = widget.api.bootstrap();
  @override bool get wantKeepAlive => true;

  void reload() => setState(() => future = widget.api.bootstrap());

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return SafeArea(
      child: FutureBuilder<BootstrapData>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return ErrorView(message: snapshot.error.toString(), onRetry: reload);
          final data = snapshot.data!;
          return RefreshIndicator(
            onRefresh: () async => reload(),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              children: [
                Row(children: [
                  CircleAvatar(radius: 25, backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: const Icon(Icons.water_drop_rounded)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(data.brandName, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    const Text('خدمات کافی‌نت، بدون مراجعه حضوری'),
                  ])),
                  IconButton(onPressed: reload, icon: const Icon(Icons.refresh)),
                ]),
                if (data.banners.isNotEmpty) ...[
                  const SizedBox(height: 18),
                  _BannerCard(banner: data.banners.first),
                ],
                const SizedBox(height: 22),
                Text('دسته‌بندی خدمات', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: data.categories.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .95),
                  itemBuilder: (context, i) => _CategoryCard(category: data.categories[i], onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ServicesScreen(api: widget.api, storage: widget.storage, category: data.categories[i])))),
                ),
                if (data.featuredServices.isNotEmpty) ...[
                  const SizedBox(height: 24),
                  Text('خدمات پرکاربرد', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  ...data.featuredServices.map((service) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _ServiceTile(service: service, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ServiceDetailScreen(api: widget.api, storage: widget.storage, serviceId: service.id)))),
                      )),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _BannerCard extends StatelessWidget {
  final BannerModel banner;
  const _BannerCard({required this.banner});
  @override
  Widget build(BuildContext context) => Container(
        height: 132,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(22)),
        child: Row(children: [
          Expanded(child: Text(banner.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
          const Icon(Icons.campaign_rounded, size: 54),
        ]),
      );
}

class _CategoryCard extends StatelessWidget {
  final CategoryModel category;
  final VoidCallback onTap;
  const _CategoryCard({required this.category, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircleAvatar(backgroundColor: Theme.of(context).colorScheme.secondaryContainer, child: const Icon(Icons.apps_rounded)),
              const SizedBox(height: 9),
              Text(category.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      );
}

class _ServiceTile extends StatelessWidget {
  final ServiceModel service;
  final VoidCallback onTap;
  const _ServiceTile({required this.service, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          onTap: onTap,
          leading: CircleAvatar(child: const Icon(Icons.description_outlined)),
          title: Text(service.title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(service.shortDescription, maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: Text(service.price == 0 ? 'استعلام' : money(service.price), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 12)),
        ),
      );
}
