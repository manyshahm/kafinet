import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/storage.dart';
import '../models/models.dart';
import '../widgets/common.dart';

class ServiceDetailScreen extends StatefulWidget {
  final ApiClient api;
  final LocalStorage storage;
  final int serviceId;
  const ServiceDetailScreen({super.key, required this.api, required this.storage, required this.serviceId});

  @override
  State<ServiceDetailScreen> createState() => _ServiceDetailScreenState();
}

class _ServiceDetailScreenState extends State<ServiceDetailScreen> {
  late Future<ServiceModel> future = widget.api.service(widget.serviceId);
  final formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final mobileController = TextEditingController();
  final Map<String, TextEditingController> controllers = {};
  final Map<String, String?> selects = {};
  bool sending = false;

  @override
  void dispose() {
    nameController.dispose();
    mobileController.dispose();
    for (final c in controllers.values) { c.dispose(); }
    super.dispose();
  }

  TextEditingController controllerFor(String key) => controllers.putIfAbsent(key, TextEditingController.new);

  Future<void> submit(ServiceModel service) async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    setState(() => sending = true);
    try {
      final answers = <String, dynamic>{};
      for (final field in service.fields) {
        answers[field.keyName] = field.type == 'select' ? selects[field.keyName] : controllerFor(field.keyName).text.trim();
      }
      final key = await widget.storage.getClientKey();
      final tracking = await widget.api.createOrder(clientKey: key, serviceId: service.id, customerName: nameController.text.trim(), mobile: mobileController.text.trim(), answers: answers);
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (context) => AlertDialog(
        title: const Text('درخواست ثبت شد'),
        content: Text('کد پیگیری شما:\n$tracking'),
        actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('متوجه شدم'))],
      ));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ثبت درخواست')),
        body: FutureBuilder<ServiceModel>(
          future: future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) return ErrorView(message: snapshot.error.toString(), onRetry: () => setState(() => future = widget.api.service(widget.serviceId)));
            final service = snapshot.data!;
            return Form(
              key: formKey,
              child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 32), children: [
                Text(service.title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(service.description.isEmpty ? service.shortDescription : service.description),
                const SizedBox(height: 12),
                Row(children: [
                  Chip(label: Text(service.price == 0 ? 'هزینه: پس از بررسی' : money(service.price))),
                  if (service.etaText.isNotEmpty) ...[const SizedBox(width: 8), Chip(label: Text(service.etaText))],
                ]),
                const SizedBox(height: 18),
                TextFormField(controller: nameController, decoration: const InputDecoration(labelText: 'نام و نام خانوادگی *'), validator: requiredValidator),
                const SizedBox(height: 12),
                TextFormField(controller: mobileController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره موبایل *'), validator: mobileValidator),
                ...service.fields.expand((field) => [const SizedBox(height: 12), buildDynamicField(field)]),
                const SizedBox(height: 22),
                FilledButton.icon(onPressed: sending ? null : () => submit(service), icon: sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send_rounded), label: const Padding(padding: EdgeInsets.symmetric(vertical: 13), child: Text('ثبت درخواست'))),
              ]),
            );
          },
        ),
      );

  Widget buildDynamicField(FormFieldModel field) {
    if (field.type == 'select') {
      return DropdownButtonFormField<String>(
        initialValue: selects[field.keyName],
        decoration: InputDecoration(labelText: '${field.label}${field.requiredField ? ' *' : ''}'),
        items: field.options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (value) => setState(() => selects[field.keyName] = value),
        validator: field.requiredField ? (v) => (v == null || v.isEmpty) ? 'این مورد الزامی است' : null : null,
      );
    }
    final keyboard = switch (field.type) {
      'number' || 'national_code' => TextInputType.number,
      'phone' => TextInputType.phone,
      _ => TextInputType.text,
    };
    return TextFormField(
      controller: controllerFor(field.keyName),
      keyboardType: field.type == 'textarea' ? TextInputType.multiline : keyboard,
      minLines: field.type == 'textarea' ? 3 : 1,
      maxLines: field.type == 'textarea' ? 5 : 1,
      decoration: InputDecoration(labelText: '${field.label}${field.requiredField ? ' *' : ''}'),
      validator: field.requiredField ? requiredValidator : null,
    );
  }

  String? requiredValidator(String? value) => value == null || value.trim().isEmpty ? 'این مورد الزامی است' : null;
  String? mobileValidator(String? value) {
    if (value == null || value.trim().isEmpty) return 'شماره موبایل الزامی است';
    if (!RegExp(r'^09\d{9}$').hasMatch(value.trim())) return 'شماره موبایل معتبر نیست';
    return null;
  }
}
