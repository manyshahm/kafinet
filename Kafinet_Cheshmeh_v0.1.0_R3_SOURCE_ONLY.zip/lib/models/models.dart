class CategoryModel {
  final int id;
  final String name;
  final String description;
  final String iconUrl;

  const CategoryModel({
    required this.id,
    required this.name,
    required this.description,
    required this.iconUrl,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
        id: (json['id'] as num).toInt(),
        name: (json['name'] ?? '').toString(),
        description: (json['description'] ?? '').toString(),
        iconUrl: (json['icon_url'] ?? '').toString(),
      );
}

class ServiceModel {
  final int id;
  final int categoryId;
  final String title;
  final String shortDescription;
  final String description;
  final int price;
  final String etaText;
  final String imageUrl;
  final bool isFeatured;
  final List<FormFieldModel> fields;

  const ServiceModel({
    required this.id,
    required this.categoryId,
    required this.title,
    required this.shortDescription,
    required this.description,
    required this.price,
    required this.etaText,
    required this.imageUrl,
    required this.isFeatured,
    required this.fields,
  });

  factory ServiceModel.fromJson(Map<String, dynamic> json) => ServiceModel(
        id: (json['id'] as num).toInt(),
        categoryId: (json['category_id'] as num? ?? 0).toInt(),
        title: (json['title'] ?? '').toString(),
        shortDescription: (json['short_description'] ?? '').toString(),
        description: (json['description'] ?? '').toString(),
        price: (json['price'] as num? ?? 0).toInt(),
        etaText: (json['eta_text'] ?? '').toString(),
        imageUrl: (json['image_url'] ?? '').toString(),
        isFeatured: json['is_featured'] == true || json['is_featured'] == 1,
        fields: ((json['form_schema'] as List?) ?? const [])
            .whereType<Map>()
            .map((e) => FormFieldModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class FormFieldModel {
  final String keyName;
  final String label;
  final String type;
  final bool requiredField;
  final List<String> options;

  const FormFieldModel({
    required this.keyName,
    required this.label,
    required this.type,
    required this.requiredField,
    required this.options,
  });

  factory FormFieldModel.fromJson(Map<String, dynamic> json) => FormFieldModel(
        keyName: (json['key'] ?? '').toString(),
        label: (json['label'] ?? '').toString(),
        type: (json['type'] ?? 'text').toString(),
        requiredField: json['required'] == true || json['required'] == 1,
        options: ((json['options'] as List?) ?? const []).map((e) => e.toString()).toList(),
      );
}

class BannerModel {
  final int id;
  final String title;
  final String imageUrl;
  final String targetType;
  final String targetValue;

  const BannerModel({required this.id, required this.title, required this.imageUrl, required this.targetType, required this.targetValue});

  factory BannerModel.fromJson(Map<String, dynamic> json) => BannerModel(
        id: (json['id'] as num).toInt(),
        title: (json['title'] ?? '').toString(),
        imageUrl: (json['image_url'] ?? '').toString(),
        targetType: (json['target_type'] ?? '').toString(),
        targetValue: (json['target_value'] ?? '').toString(),
      );
}

class BootstrapData {
  final String brandName;
  final String supportPhone;
  final List<CategoryModel> categories;
  final List<ServiceModel> featuredServices;
  final List<BannerModel> banners;

  const BootstrapData({required this.brandName, required this.supportPhone, required this.categories, required this.featuredServices, required this.banners});

  factory BootstrapData.fromJson(Map<String, dynamic> json) {
    final settings = Map<String, dynamic>.from(json['settings'] as Map? ?? const {});
    return BootstrapData(
      brandName: (settings['brand_name'] ?? 'کافی‌نت چشمه').toString(),
      supportPhone: (settings['support_phone'] ?? '').toString(),
      categories: ((json['categories'] as List?) ?? const []).whereType<Map>().map((e) => CategoryModel.fromJson(Map<String, dynamic>.from(e))).toList(),
      featuredServices: ((json['featured_services'] as List?) ?? const []).whereType<Map>().map((e) => ServiceModel.fromJson(Map<String, dynamic>.from(e))).toList(),
      banners: ((json['banners'] as List?) ?? const []).whereType<Map>().map((e) => BannerModel.fromJson(Map<String, dynamic>.from(e))).toList(),
    );
  }
}

class OrderModel {
  final String trackingCode;
  final String serviceTitle;
  final int totalAmount;
  final String status;
  final String adminNote;
  final String createdAt;

  const OrderModel({required this.trackingCode, required this.serviceTitle, required this.totalAmount, required this.status, required this.adminNote, required this.createdAt});

  factory OrderModel.fromJson(Map<String, dynamic> json) => OrderModel(
        trackingCode: (json['tracking_code'] ?? '').toString(),
        serviceTitle: (json['service_title'] ?? '').toString(),
        totalAmount: (json['total_amount'] as num? ?? 0).toInt(),
        status: (json['status'] ?? 'new').toString(),
        adminNote: (json['admin_note'] ?? '').toString(),
        createdAt: (json['created_at'] ?? '').toString(),
      );
}
