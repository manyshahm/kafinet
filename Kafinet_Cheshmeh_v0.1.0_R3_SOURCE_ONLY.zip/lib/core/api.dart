import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/models.dart';
import 'app_config.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class ApiClient {
  final http.Client _client;
  ApiClient({http.Client? client}) : _client = client ?? http.Client();

  Uri _uri(String path, [Map<String, String>? query]) => Uri.parse('${AppConfig.apiBaseUrl}$path').replace(queryParameters: query);

  Future<Map<String, dynamic>> _get(String path, [Map<String, String>? query]) async {
    final response = await _client.get(_uri(path, query), headers: const {'Accept': 'application/json'}).timeout(const Duration(seconds: 15));
    return _decode(response);
  }

  Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> payload) async {
    final response = await _client
        .post(_uri(path), headers: const {'Accept': 'application/json', 'Content-Type': 'application/json'}, body: jsonEncode(payload))
        .timeout(const Duration(seconds: 20));
    return _decode(response);
  }

  Map<String, dynamic> _decode(http.Response response) {
    Map<String, dynamic> body;
    try {
      body = Map<String, dynamic>.from(jsonDecode(response.body) as Map);
    } catch (_) {
      throw ApiException('پاسخ نامعتبر از سرور دریافت شد.');
    }
    if (response.statusCode < 200 || response.statusCode >= 300 || body['ok'] != true) {
      throw ApiException((body['message'] ?? 'خطا در ارتباط با سرور').toString());
    }
    return Map<String, dynamic>.from(body['data'] as Map? ?? const {});
  }

  Future<BootstrapData> bootstrap() async => BootstrapData.fromJson(await _get('/bootstrap'));

  Future<List<ServiceModel>> servicesByCategory(int categoryId) async {
    final data = await _get('/services', {'category_id': '$categoryId'});
    return ((data['items'] as List?) ?? const []).whereType<Map>().map((e) => ServiceModel.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<ServiceModel> service(int id) async => ServiceModel.fromJson(await _get('/services/$id'));

  Future<String> createOrder({
    required String clientKey,
    required int serviceId,
    required String customerName,
    required String mobile,
    required Map<String, dynamic> answers,
  }) async {
    final data = await _post('/orders', {
      'client_key': clientKey,
      'service_id': serviceId,
      'customer_name': customerName,
      'mobile': mobile,
      'answers': answers,
    });
    return (data['tracking_code'] ?? '').toString();
  }

  Future<List<OrderModel>> orders(String clientKey) async {
    final data = await _get('/orders', {'client_key': clientKey});
    return ((data['items'] as List?) ?? const []).whereType<Map>().map((e) => OrderModel.fromJson(Map<String, dynamic>.from(e))).toList();
  }
}
