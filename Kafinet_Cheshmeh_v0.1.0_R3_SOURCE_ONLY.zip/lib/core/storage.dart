import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

class LocalStorage {
  static const _clientKey = 'client_key';

  Future<String> getClientKey() async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getString(_clientKey);
    if (current != null && current.isNotEmpty) return current;
    final random = Random.secure();
    final key = List.generate(24, (_) => random.nextInt(16).toRadixString(16)).join();
    await prefs.setString(_clientKey, key);
    return key;
  }
}
