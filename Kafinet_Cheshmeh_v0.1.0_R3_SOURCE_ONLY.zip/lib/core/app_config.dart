class AppConfig {
  static const appName = 'کافی‌نت چشمه';
  static const apiBaseUrl = 'https://persian-melody.ir/kafinet/api';
  static const appVersion = '0.1.0';
}
