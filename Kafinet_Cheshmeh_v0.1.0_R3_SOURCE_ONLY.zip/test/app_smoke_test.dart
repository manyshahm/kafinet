import 'package:flutter_test/flutter_test.dart';
import 'package:kafinet_cheshmeh/core/app_config.dart';
import 'package:kafinet_cheshmeh/models/models.dart';

void main() {
  test('API base URL points to production kafinet path', () {
    expect(AppConfig.apiBaseUrl, 'https://persian-melody.ir/kafinet/api');
  });

  test('dynamic service schema parses correctly', () {
    final service = ServiceModel.fromJson({
      'id': 1,
      'category_id': 2,
      'title': 'تست',
      'price': 1000,
      'form_schema': [
        {
          'key': 'national_code',
          'label': 'کد ملی',
          'type': 'national_code',
          'required': true,
          'options': [],
        }
      ],
    });
    expect(service.fields.single.keyName, 'national_code');
    expect(service.fields.single.requiredField, isTrue);
  });
}
