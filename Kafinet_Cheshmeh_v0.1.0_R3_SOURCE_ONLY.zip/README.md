# کافی‌نت چشمه — Flutter v0.1.0 (Signing R2)

اپ سبک و Server-Driven. آدرس Production API:

`https://persian-melody.ir/kafinet/api`

## Android Package

`ir.miplus.kafinet`

## امضای Release

این بسته از همان Keystore اصلی گامینو استفاده می‌کند:

- فایل: `build_support/gamino-release-key.jks`
- Alias: `gamino_release`
- Keystore SHA-256: `4498395d237db683265e384e590dc07580d5d76918d5ea0351cb0d09dd5da312`
- Certificate SHA-256: `93:7A:45:CB:0C:47:B3:F6:20:A1:79:C1:D1:82:98:89:BF:F1:22:9F:92:5B:C4:D0:99:40:7B:28:7E:87:66:B6`

> این Repository شامل کلید امضای واقعی است؛ آن را Public نکنید.

## Build با GitHub Actions

محتویات ZIP را در ریشه Repository خصوصی قرار دهید و Push کنید. Workflow:

1. Flutter `3.38.7` را نصب می‌کند.
2. SHA-256 Keystore گامینو را کنترل می‌کند.
3. Android scaffold را با Package دقیق `ir.miplus.kafinet` می‌سازد.
4. Signing Release را با Keystore گامینو تنظیم می‌کند.
5. `flutter analyze` و `flutter test` را اجرا می‌کند.
6. APK و AAB Release امضاشده می‌سازد.
7. Package و Certificate خروجی APK را کنترل می‌کند.
8. APK/AAB و SHA256 را به‌عنوان Artifact تحویل می‌دهد.

## نکته نسخه آزمایشی

برای تست سریع، ورود پیامکی هنوز اجباری نشده است. هر نصب یک `client_key` تصادفی محلی دارد و سفارش‌های همان نصب را می‌بیند.
